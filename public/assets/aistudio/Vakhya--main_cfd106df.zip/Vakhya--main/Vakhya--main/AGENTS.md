# VAKHYA AI – Master Architectural Guidelines

This workspace represents the full-stack web simulation portal of **VAKHYA AI** — an AI-powered accessibility communication ecosystem designed to bridge interaction gaps for Deaf, Hard-of-Hearing, Speech-Impaired, and Hearing users.

## 🛠 Technology Stack Reference

### 1. Front-End Applet Structure
* **Runtime**: React 18+ with Vite and TypeScript.
* **Animations**: Fluid, hardware-accelerated transitions powered by `motion/react`.
* **Icons**: Standardized vector interfaces imported exclusively from `lucide-react`.
* **Styling**: Tailwind CSS utilizing the custom dual-mode Aurora palette mapping.

### 2. Back-End Service (Express + Vite Orchestrated)
* **Server**: Node.js + Express + TypeScript `server.ts`.
* **Build System**: Bundle-compiled via `esbuild` into a unified `dist/server.cjs` container asset.
* **AI Engine**: Advanced server-side integrations using the official `@google/genai` SDK on `gemini-3.5-flash`.
* **OTP Simulation**: Cryptographically safe 6-digit verification code flows with expiration timeouts, SMS gateway mimics, and sequential entry helpers.

---

## 🎨 Global UI/UX Philosophy

### Dual-Theme Palette Mapping
Vakhya utilizes two high-fidelity visual configurations mapped globally through CSS custom properties inside `/src/theme.css`:
1. **Aurora Daylight (Default Light Mode)**: Soft lavender off-whites, crisp slate text, and vibrant violet/magenta interactive focal spots.
2. **Lavender Aurora (Dark Mode)**: Immersive cosmic dark-grape palette, high-contrast violet glow backdrops, and cyan/magenta active triggers.

### Accessible Sizing Controls
Adheres strictly to accessibility-first heuristics:
* **Skeletal Overlay Alignment**: Computer vision trace simulations with 21-point hand joint coordinates.
* **WCAG Contrast standards**: High contrast mode controls, rich haptic simulations, and screen-flash visual notifications.

---

## 🔒 Security & Data Heuristics
* **Encrypted Back-ends**: Critical API keys (e.g., `GEMINI_API_KEY`) must **never** be exposed in browser modules. Always proxy through Express routes (`/api/*`).
* **Session Persistence**: Secure persistent data caches using browser `localStorage` under `vakhya_profile`.
