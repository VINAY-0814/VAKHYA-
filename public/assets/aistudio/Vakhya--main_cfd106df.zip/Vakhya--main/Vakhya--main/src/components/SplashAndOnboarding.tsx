/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Volume2, Hand, MessageSquare, ArrowRight, Accessibility } from "lucide-react";
import { theme } from "../theme";

interface SplashAndOnboardingProps {
  onComplete: () => void;
}

export default function SplashAndOnboarding({ onComplete }: SplashAndOnboardingProps) {
  const [showSplash, setShowSplash] = useState(true);
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  const slides = [
    {
      title: "Break the Silence",
      description: "Experience fully interactive speech-to-sign and sign-to-speech translations in real-time, built for absolute conversational clarity.",
      icon: <Hand className="w-16 h-16 text-[#25D366]" />,
      illustration: (
        <div className="relative w-48 h-48 mx-auto flex items-center justify-center">
          <div className="absolute inset-0 bg-gradient-to-tr from-[#075E54] to-[#25D366] opacity-20 blur-3xl rounded-full animate-pulse" />
          <div className="relative p-6 bg-white/40 backdrop-blur-md border border-white/20 rounded-3xl shadow-xl">
            <Hand className="w-24 h-24 text-[#128C7E] animate-bounce" />
          </div>
        </div>
      ),
    },
    {
      title: "Real-Time 3D Avatar",
      description: "Hearing voices instantly morph into an elegant, expressive, 3D animated character signing with 21-point custom hand skeletal rigs.",
      icon: <Accessibility className="w-16 h-16 text-[#25D366]" />,
      illustration: (
        <div className="relative w-48 h-48 mx-auto flex items-center justify-center">
          <div className="absolute inset-0 bg-gradient-to-tr from-[#25D366] to-[#DCF8C6] opacity-35 blur-2xl rounded-full" />
          <div className="relative p-5 bg-white/50 backdrop-blur-md border border-white/20 rounded-3xl shadow-2xl flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#075E54] to-[#128C7E] flex items-center justify-center text-white font-bold text-lg mb-2">
              VK
            </div>
            <div className="flex gap-1.5 justify-center items-end h-8">
              <span className="w-1.5 h-6 bg-[#128C7E] rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
              <span className="w-1.5 h-8 bg-[#25D366] rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
              <span className="w-1.5 h-5 bg-[#075E54] rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
            </div>
          </div>
        </div>
      ),
    },
    {
      title: "Natural Voice Modulation",
      description: "Customise pitch, speed, and warmth sliders or use voice cloning to synthesize a beautiful spoken voice that feels uniquely yours.",
      icon: <Volume2 className="w-16 h-16 text-[#075E54]" />,
      illustration: (
        <div className="relative w-48 h-48 mx-auto flex items-center justify-center">
          <div className="absolute inset-0 bg-gradient-to-tr from-[#075E54] to-[#DCF8C6] opacity-25 blur-3xl rounded-full animate-pulse" />
          <div className="relative p-6 bg-white/40 backdrop-blur-md border border-white/20 rounded-3xl shadow-xl">
            <Volume2 className="w-20 h-20 text-[#25D366] animate-pulse" />
          </div>
        </div>
      ),
    },
    {
      title: "Interactive Video Calls",
      description: "Conduct seamless 1:1 mobile video calling overlaid with automated gesture translations and speech captions running dual-directionally.",
      icon: <MessageSquare className="w-16 h-16 text-[#075E54]" />,
      illustration: (
        <div className="relative w-48 h-48 mx-auto flex items-center justify-center">
          <div className="absolute inset-0 bg-gradient-to-tr from-[#25D366] to-[#128C7E] opacity-20 blur-2xl rounded-full" />
          <div className="relative p-4 bg-white/40 backdrop-blur-md border border-white/20 rounded-3xl shadow-xl flex gap-3">
            <div className="w-16 h-24 bg-[#111B21] rounded-xl flex items-center justify-center border border-white/10 shadow-inner">
              <span className="text-[10px] text-white/60 font-mono">Signer</span>
            </div>
            <div className="w-16 h-24 bg-[#075E54] rounded-xl flex items-center justify-center border border-white/10 shadow-md">
              <span className="text-[10px] text-white/80 font-mono">Avatar</span>
            </div>
          </div>
        </div>
      ),
    },
  ];

  if (showSplash) {
    return (
      <div
        id="splash-container"
        className="fixed inset-0 flex flex-col items-center justify-center text-white overflow-hidden"
        style={{ background: theme.gradients.aurora }}
      >
        {/* Animated Aurora Blobs */}
        <div className="absolute w-[350px] h-[350px] bg-[#075E54] rounded-full filter blur-[80px] opacity-40 top-1/4 left-1/4 animate-pulse" />
        <div className="absolute w-[300px] h-[300px] bg-[#25D366] rounded-full filter blur-[100px] opacity-30 bottom-1/4 right-1/4 animate-pulse" />

        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="text-center z-10"
        >
          <div className="w-28 h-28 mx-auto mb-6 rounded-3xl bg-gradient-to-tr from-[#128C7E] to-[#25D366] flex items-center justify-center shadow-2xl shadow-emerald-950/40 border border-white/20">
            <Hand className="w-16 h-16 text-white" />
          </div>
          <h1 className="text-5xl font-extrabold tracking-tight bg-gradient-to-r from-white via-[#DCF8C6] to-white bg-clip-text text-transparent">
            VAKHYA
          </h1>
          <p className="text-sm mt-3 uppercase tracking-widest text-[#25D366] font-medium">
            Breaking Silence with AI
          </p>
        </motion.div>
        <div className="absolute bottom-12 text-xs text-white/40 font-mono tracking-wider">
          Accessibility Ecosystem v1.0
        </div>
      </div>
    );
  }

  return (
    <div
      id="onboarding-container"
      className="min-h-screen flex flex-col items-center justify-center p-6 text-white relative overflow-hidden"
      style={{ background: theme.gradients.aurora }}
    >
      {/* Aurora Ambient Blobs */}
      <div className="absolute w-80 h-80 bg-[#075E54] rounded-full filter blur-[80px] opacity-35 top-10 left-10" />
      <div className="absolute w-80 h-80 bg-[#25D366] rounded-full filter blur-[80px] opacity-25 bottom-10 right-10" />

      <div className={`w-full max-w-md ${theme.styles.glassDark} p-8 flex flex-col justify-between min-h-[580px] z-10`}>
        {/* Header with logo & skip */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#128C7E] to-[#25D366] flex items-center justify-center">
              <Hand className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold tracking-wider text-sm text-white">VAKHYA</span>
          </div>
          <button
            id="onboarding-skip-btn"
            onClick={onComplete}
            className="text-xs text-[#25D366] hover:text-white transition-colors bg-white/5 px-3 py-1.5 rounded-full border border-white/5 hover:bg-white/10"
          >
            Skip
          </button>
        </div>

        {/* Carousel Illustration */}
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.4 }}
          className="my-4 text-center"
        >
          {slides[currentSlide].illustration}
          <h2 className="text-2xl font-bold mt-6 mb-3 text-white">
            {slides[currentSlide].title}
          </h2>
          <p className="text-sm text-white/70 leading-relaxed max-w-sm mx-auto">
            {slides[currentSlide].description}
          </p>
        </motion.div>

        {/* Slide Indicators and CTA */}
        <div>
          <div className="flex justify-center gap-2 mb-8">
            {slides.map((_, index) => (
              <span
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-2 rounded-full cursor-pointer transition-all ${
                  index === currentSlide ? "w-6 bg-[#25D366]" : "w-2 bg-white/20"
                }`}
              />
            ))}
          </div>

          <div className="flex gap-4">
            {currentSlide > 0 && (
              <button
                id="onboarding-prev-btn"
                onClick={() => setCurrentSlide(currentSlide - 1)}
                className="w-1/3 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white font-medium text-sm border border-white/10 transition-colors"
              >
                Back
              </button>
            )}
            <button
              id="onboarding-next-btn"
              onClick={() => {
                if (currentSlide === slides.length - 1) {
                  onComplete();
                } else {
                  setCurrentSlide(currentSlide + 1);
                }
              }}
              className={`flex-1 py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 ${theme.styles.buttonAccent}`}
            >
              {currentSlide === slides.length - 1 ? "Get Started" : "Continue"}
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
