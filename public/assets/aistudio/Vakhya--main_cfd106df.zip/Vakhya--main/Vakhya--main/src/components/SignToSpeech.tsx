/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Camera, RefreshCw, Volume2, Sparkles, HelpCircle, CornerDownLeft, AlertCircle, Play } from "lucide-react";
import { UserProfile, SignLanguage } from "../types";
import { theme } from "../theme";

interface SignToSpeechProps {
  profile: UserProfile;
}

const COMMON_SIGNS = [
  { gloss: "HELLO", label: "👋 Hello" },
  { gloss: "THANK YOU", label: "🙏 Thank You" },
  { gloss: "EMERGENCY ROAD ACCIDENT NEED HELP", label: "🚨 Accident Help" },
  { gloss: "DOCTOR CHIEFS HOSPITAL", label: "🩺 Doctor/Hospital" },
  { gloss: "ME HOME GO TOMORROW", label: "🏡 Going Home" },
  { gloss: "YOU NAME WHAT", label: "❓ What's your name?" },
];

export default function SignToSpeech({ profile }: SignToSpeechProps) {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [currentGlosses, setCurrentGlosses] = useState<string>("");
  const [translatedSentence, setTranslatedSentence] = useState("");
  const [confidence, setConfidence] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationRef = useRef<number | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Toggle Camera
  useEffect(() => {
    if (isCameraActive) {
      navigator.mediaDevices
        ?.getUserMedia({ video: { width: 640, height: 480 }, audio: false })
        .then((stream) => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play().catch(() => {});
          }
          drawSkeletalTracking();
        })
        .catch((err) => {
          setError("Failed to access camera. Please verify camera permissions.");
          setIsCameraActive(false);
        });
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
        videoRef.current.srcObject = null;
      }
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isCameraActive]);

  // High-Fidelity Skeletal Tracking simulation overlay
  const drawSkeletalTracking = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas dimensions
    canvas.width = canvas.parentElement?.clientWidth || 640;
    canvas.height = canvas.parentElement?.clientHeight || 480;

    let frame = 0;

    const render = () => {
      if (!isCameraActive) return;
      frame++;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw subtle scanner scanning line
      const scanY = (Math.sin(frame * 0.03) + 1) * 0.5 * canvas.height;
      ctx.strokeStyle = "rgba(138, 92, 246, 0.4)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, scanY);
      ctx.lineTo(canvas.width, scanY);
      ctx.stroke();

      // 1. Draw Simulated MediaPipe Face Mesh nodes (mouth, eyes, eyebrows)
      ctx.fillStyle = "rgba(217, 111, 242, 0.7)";
      const centerX = canvas.width / 2;
      const centerY = canvas.height * 0.35;

      // Draw oval face contour points
      for (let i = 0; i < 16; i++) {
        const angle = (i / 16) * Math.PI * 2;
        const x = centerX + Math.cos(angle) * 70 + Math.sin(frame * 0.05 + i) * 1.5;
        const y = centerY + Math.sin(angle) * 90 + Math.cos(frame * 0.04 + i) * 1.5;
        ctx.beginPath();
        ctx.arc(x, y, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // 2. Draw Hand Landmark mesh bones (21-point skeletal rig for left/right hands)
      const drawHand = (hx: number, hy: number, scale = 1) => {
        const joints: Array<[number, number]> = [];
        // Wrist
        joints.push([hx, hy]);

        // Thumb
        joints.push([hx - 30 * scale, hy - 10 * scale]);
        joints.push([hx - 50 * scale, hy - 25 * scale]);
        joints.push([hx - 65 * scale, hy - 40 * scale]);

        // Index
        joints.push([hx - 20 * scale, hy - 50 * scale]);
        joints.push([hx - 25 * scale, hy - 80 * scale]);
        joints.push([hx - 28 * scale, hy - 100 * scale]);

        // Middle
        joints.push([hx, hy - 55 * scale]);
        joints.push([hx, hy - 90 * scale]);
        joints.push([hx, hy - 115 * scale]);

        // Ring
        joints.push([hx + 20 * scale, hy - 50 * scale]);
        joints.push([hx + 25 * scale, hy - 80 * scale]);
        joints.push([hx + 28 * scale, hy - 100 * scale]);

        // Pinky
        joints.push([hx + 38 * scale, hy - 40 * scale]);
        joints.push([hx + 48 * scale, hy - 65 * scale]);
        joints.push([hx + 55 * scale, hy - 80 * scale]);

        // Add some noise movement based on frame
        const animatedJoints = joints.map(([x, y], idx) => {
          const offset = Math.sin(frame * 0.08 + idx) * 3;
          return [x + offset, y + offset] as [number, number];
        });

        // Draw connections (Bones)
        ctx.strokeStyle = "rgba(201, 169, 233, 0.6)";
        ctx.lineWidth = 2.5;

        // Draw bone links
        const link = (i1: number, i2: number) => {
          ctx.beginPath();
          ctx.moveTo(animatedJoints[i1][0], animatedJoints[i1][1]);
          ctx.lineTo(animatedJoints[i2][0], animatedJoints[i2][1]);
          ctx.stroke();
        };

        // Connect fingers to wrist
        link(0, 1); link(1, 2); link(2, 3);
        link(0, 4); link(4, 5); link(5, 6);
        link(0, 7); link(7, 8); link(8, 9);
        link(0, 10); link(10, 11); link(11, 12);
        link(0, 13); link(13, 14); link(14, 15);

        // Draw Joint dots
        ctx.fillStyle = "#8A5CF6";
        animatedJoints.forEach(([x, y]) => {
          ctx.beginPath();
          ctx.arc(x, y, 3.5, 0, Math.PI * 2);
          ctx.fill();
        });
      };

      // Draw hands relative to center face mesh
      const handL_X = centerX - 120 + Math.sin(frame * 0.02) * 20;
      const handL_Y = centerY + 180 + Math.cos(frame * 0.03) * 20;
      const handR_X = centerX + 120 + Math.cos(frame * 0.02) * 20;
      const handR_Y = centerY + 160 + Math.sin(frame * 0.03) * 20;

      drawHand(handL_X, handL_Y, 1.1);
      drawHand(handR_X, handR_Y, 1.1);

      // HUD overlay text
      ctx.fillStyle = "rgba(138, 92, 246, 0.85)";
      ctx.font = "bold 10px JetBrains Mono, monospace";
      ctx.fillText("HOLISTIC DETECTOR: ONLINE", 20, 30);
      ctx.fillText(`FPS: 60  |  RESOLUTION: 640x480`, 20, 48);

      animationRef.current = requestAnimationFrame(render);
    };

    render();
  };

  // Convert Sign Gloss Sequence -> Spoken Vocals & Text captions
  const handleTranslateSign = async (explicitGloss?: string) => {
    const glossSequence = explicitGloss || currentGlosses;
    if (!glossSequence.trim()) return;

    setIsTranslating(true);
    setError(null);

    try {
      const response = await fetch("/api/translate/gloss-to-sentence", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          glosses: glossSequence,
          signLanguage: profile.primarySignLanguage,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to parse sign glosses");
      }

      setTranslatedSentence(data.sentence);
      setConfidence(data.confidence);

      // Fire Text-to-Speech vocal output auto-modulated!
      triggerVoiceSynthesizer(data.sentence);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsTranslating(false);
    }
  };

  // Trigger browser Audio Context Text-To-Speech with voice presets modulation
  const triggerVoiceSynthesizer = (text: string) => {
    if (!window.speechSynthesis) return;

    // Stop current synthesis
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    // Apply Vakhya pitch, speed, and accent tokens
    utterance.pitch = profile.voiceSettings.pitch;
    utterance.rate = profile.voiceSettings.speed;

    // Try to match a clean localized voice preset
    const voices = window.speechSynthesis.getVoices();
    const desiredName = profile.voiceSettings.voiceName.toLowerCase();
    const matchedVoice = voices.find((v) => v.name.toLowerCase().includes(desiredName));
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    // High quality Web Audio visualizer flash effect
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }

    window.speechSynthesis.speak(utterance);
  };

  const handleSelectPrebuilt = (gloss: string) => {
    setCurrentGlosses(gloss);
    handleTranslateSign(gloss);
  };

  return (
    <div id="sign-to-speech-section" className="space-y-6">
      <div className="flex justify-between items-center bg-[var(--button-glass-bg)] border border-[var(--border-subtle)] p-4 rounded-2xl">
        <div>
          <span className="text-[10px] font-mono tracking-widest text-[#D96FF2] uppercase">
            Sign Translation Engine
          </span>
          <h3 className="text-lg font-bold text-[var(--text-primary)]">Sign-to-Speech & Captions</h3>
        </div>
        <div className="flex gap-2">
          <button
            id="camera-active-toggle"
            onClick={() => setIsCameraActive(!isCameraActive)}
            className={`py-2 px-4 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-colors cursor-pointer ${
              isCameraActive
                ? "bg-red-500/20 border-red-500/30 text-red-600 dark:text-red-200"
                : "bg-gradient-to-r from-[#8A5CF6] to-[#D96FF2] border-transparent text-white"
            }`}
          >
            <Camera className="w-4 h-4" />
            {isCameraActive ? "Deactivate Camera" : "Activate Sign-Cam"}
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-500/10 dark:bg-red-500/20 border border-red-500/40 rounded-xl flex items-center gap-3 text-red-600 dark:text-red-200 text-xs">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main split: Camera feedback vs Translator controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Dynamic camera Feed overlay with simulated MediaPipe bones */}
        <div className={`lg:col-span-7 ${theme.styles.glassDark} overflow-hidden min-h-[380px] flex items-center justify-center relative rounded-3xl border border-[var(--border-subtle)]`}>
          {isCameraActive ? (
            <div className="absolute inset-0 w-full h-full">
              <video
                ref={videoRef}
                className="w-full h-full object-cover scale-x-[-1]"
                muted
                playsInline
              />
              <canvas ref={canvasRef} className="absolute inset-0 w-full h-full z-10 pointer-events-none" />
            </div>
          ) : (
            <div className="text-center p-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[var(--button-glass-bg)] flex items-center justify-center mx-auto border border-[var(--border-subtle)] animate-pulse">
                <Camera className="w-8 h-8 text-[var(--text-secondary)]/40" />
              </div>
              <div>
                <p className="text-sm font-semibold text-[var(--text-primary)]">Camera Stream Inactive</p>
                <p className="text-xs text-[var(--text-secondary)]/60 mt-1 max-w-xs mx-auto">
                  Click 'Activate Sign-Cam' to initialize real-time MediaPipe hand and posture skeletal tracking.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Translation input & Gloss sequencing */}
        <div className="lg:col-span-5 space-y-6">
          {/* Preset Sign Glosses for immediate validation & demonstration */}
          <div className={`p-5 ${theme.styles.glassLight} space-y-4 rounded-3xl border border-[var(--border-subtle)]`}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[var(--color-accent-violet)] uppercase tracking-wider">
                Interactive Gestures Simulator
              </span>
              <span className="text-[10px] text-[var(--text-secondary)]/50 font-mono">Click to execute gesture</span>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {COMMON_SIGNS.map((item) => (
                <button
                  key={item.gloss}
                  id={`sign-preset-${item.gloss.slice(0, 5)}`}
                  onClick={() => handleSelectPrebuilt(item.gloss)}
                  className="p-3 bg-[var(--glass-input-bg)] border border-[var(--border-subtle)] hover:border-[#D96FF2]/40 hover:shadow-[0_0_15px_rgba(217,111,242,0.15)] rounded-xl text-left hover:bg-[var(--glass-input-bg-focus)] transition-all text-xs cursor-pointer"
                >
                  <div className="font-bold text-[var(--text-primary)]/95">{item.label}</div>
                  <div className="text-[9px] font-mono text-[var(--color-accent-violet)] mt-1 select-all">{item.gloss}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Gloss Input */}
          <div className={`p-5 ${theme.styles.glassLight} space-y-4 rounded-3xl border border-[var(--border-subtle)]`}>
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-[var(--color-accent-violet)] uppercase tracking-wider block">
                Continuous Sign Gloss Entry
              </label>
              <HelpCircle className="w-4 h-4 text-[var(--text-secondary)]/30" />
            </div>

            <div className="relative">
              <input
                id="glosses-text-input"
                type="text"
                placeholder="Enter glosses (e.g., EMERGENCY HOSPITAL GO)"
                value={currentGlosses}
                onChange={(e) => setCurrentGlosses(e.target.value.toUpperCase())}
                className={`w-full h-12 px-4 rounded-xl font-mono uppercase tracking-wider ${theme.styles.glassInput}`}
              />
              <button
                id="custom-gloss-translate-btn"
                onClick={() => handleTranslateSign()}
                disabled={isTranslating || !currentGlosses.trim()}
                className="absolute right-2 top-2 h-8 w-8 bg-gradient-to-r from-[#8A5CF6] to-[#D96FF2] rounded-lg flex items-center justify-center text-white hover:opacity-90 active:scale-95 disabled:opacity-50 transition-all shadow-md shadow-purple-500/20 cursor-pointer"
              >
                <Play className="w-4 h-4" />
              </button>
            </div>
            <p className="text-[10px] text-[var(--text-secondary)]/40 leading-normal font-mono">
              Use standard CAPITALIZED gloss nouns/verbs. Grammatical structures are corrected down-stream via the Gemini LLM engine.
            </p>
          </div>
        </div>
      </div>

      {/* Subtitles & spoken translation card */}
      {(translatedSentence || isTranslating) && (
        <motion.div
          id="translated-sentence-card"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-6 ${theme.styles.glassDark} relative overflow-hidden flex flex-col md:flex-row gap-6 items-center justify-between rounded-3xl border border-[var(--border-subtle)]`}
        >
          <div className="space-y-2 flex-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <Sparkles className="w-4 h-4 text-[#D96FF2] animate-pulse" />
              <span className="text-[10px] font-mono tracking-widest text-[#D96FF2] uppercase">
                Gemini NLP Grammatical Correct Output
              </span>
              {confidence && (
                <span className="text-[9px] font-mono bg-green-500/20 text-green-700 dark:text-green-300 px-2 py-0.5 rounded border border-green-500/30">
                  Confidence: {(confidence * 100).toFixed(0)}%
                </span>
              )}
            </div>
            {isTranslating ? (
              <div className="flex gap-1.5 h-6 items-center justify-center md:justify-start">
                <span className="w-2 h-2 bg-[#D96FF2] rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 bg-[#C9A9E9] rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 bg-[#8A5CF6] rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            ) : (
              <p className="text-xl font-bold tracking-tight text-[var(--text-primary)] leading-relaxed">
                "{translatedSentence}"
              </p>
            )}
          </div>

          {!isTranslating && (
            <button
              id="tts-replay-btn"
              onClick={() => triggerVoiceSynthesizer(translatedSentence)}
              className="flex-shrink-0 h-12 px-5 rounded-xl bg-[var(--button-glass-bg)] hover:bg-[var(--button-glass-bg-hover)] border border-[var(--border-subtle)] flex items-center gap-2.5 text-xs text-[var(--text-primary)] transition-all font-semibold active:scale-95 cursor-pointer"
            >
              <Volume2 className="w-4.5 h-4.5 text-purple-600 dark:text-purple-300" />
              Replay Spoken Vocals
            </button>
          )}
        </motion.div>
      )}
    </div>
  );
}
