/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  PhoneOff,
  Video,
  Mic,
  MicOff,
  Sparkles,
  ShieldAlert,
  Sliders,
  Maximize2,
  Copy,
  MessageSquare,
  Volume2,
  UserCheck,
  CheckCircle,
  Clock,
  RefreshCw,
  X,
  Send,
  AlertTriangle,
  UserPlus,
  Smartphone,
  Zap,
  VolumeX,
  Languages,
  Bell
} from "lucide-react";
import { theme } from "../theme";
import InCallScreen from "./calls/InCallScreen";
import IncomingCallIntent from "./IncomingCallIntent";

interface CallingOverlayProps {
  callState: "idle" | "incoming" | "outgoing" | "connected" | "ended";
  callContact: any;
  callType: "voice" | "video";
  onEndCall: () => void;
  onAcceptCall: () => void;
  selectedVoicePreset: string;
  onUpdateVoicePreset: (preset: string) => void;
}

export default function CallingOverlay({
  callState,
  callContact,
  callType,
  onEndCall,
  onAcceptCall,
  selectedVoicePreset,
  onUpdateVoicePreset
}: CallingOverlayProps) {
  const [isMuted, setIsMuted] = useState(false);
  const [isCamOn, setIsCamOn] = useState(true);
  const [showAvatarOverlay, setShowAvatarOverlay] = useState(true);
  const [interpreterAdded, setInterpreterAdded] = useState(false);
  const [activeSpeaker, setActiveSpeaker] = useState<"remote" | "me" | "interpreter">("remote");
  const [callDuration, setCallDuration] = useState(0);
  const [inCallDrawerOpen, setInCallDrawerOpen] = useState(false);
  const [networkQuality, setNetworkQuality] = useState<"excellent" | "poor" | "reconnecting">("excellent");

  // Chat messages inside the active call
  const [inCallMessages, setInCallMessages] = useState<any[]>([
    { sender: "remote", text: "Connecting. Translation engine calibrated successfully.", time: "12:00 AM" }
  ]);
  const [currentInCallInput, setCurrentInCallInput] = useState("");

  // Draggable PiP coordinates
  const [pipCorner, setPipCorner] = useState<"top-left" | "top-right" | "bottom-left" | "bottom-right">("bottom-right");
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const durationTimerRef = useRef<any>(null);

  // Sign language translation stream simulation
  const [activeGloss, setActiveGloss] = useState("IDLE");
  const [activeCaptions, setActiveCaptions] = useState("Awaiting active speech stream...");
  const avatarCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Setup simulated calling loop
  useEffect(() => {
    if (callState === "connected") {
      setCallDuration(0);
      durationTimerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);

      // Start simulated speech translations
      startConversationSimulation();
    } else {
      if (durationTimerRef.current) clearInterval(durationTimerRef.current);
    }
    return () => {
      if (durationTimerRef.current) clearInterval(durationTimerRef.current);
    };
  }, [callState]);

  // Handle local camera access for PiP
  useEffect(() => {
    if (callState === "connected" && isCamOn) {
      navigator.mediaDevices
        ?.getUserMedia({ video: { width: 160, height: 120 }, audio: false })
        .then((stream) => {
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
            localVideoRef.current.play().catch(() => {});
          }
        })
        .catch(() => {});
    }
  }, [callState, isCamOn]);

  // Render the WebRTC 3D Avatar coordinates simulation
  useEffect(() => {
    if (callState === "connected" && showAvatarOverlay) {
      const canvas = avatarCanvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          canvas.width = 160;
          canvas.height = 200;
          let frame = 0;

          const draw = () => {
            frame++;
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Clean background
            ctx.fillStyle = "#1E1435";
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Pulse center target
            ctx.strokeStyle = "rgba(138, 92, 246, 0.4)";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(canvas.width / 2, canvas.height / 2 - 20, 30 + Math.sin(frame * 0.1) * 8, 0, Math.PI * 2);
            ctx.stroke();

            // Face mesh dots
            ctx.fillStyle = "#D96FF2";
            const fx = canvas.width / 2;
            const fy = canvas.height / 2 - 40;
            ctx.beginPath();
            ctx.arc(fx, fy, 4, 0, Math.PI * 2); // Nose
            ctx.arc(fx - 10, fy - 6, 2.5, 0, Math.PI * 2); // Left eye
            ctx.arc(fx + 10, fy - 6, 2.5, 0, Math.PI * 2); // Right eye
            ctx.fill();

            // Mouth mouth mapping
            ctx.strokeStyle = "#8A5CF6";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(fx, fy + 8, 6, 0, Math.PI + (Math.sin(frame * 0.12) + 1) * 0.5);
            ctx.stroke();

            // Joint bones skeletal links
            ctx.strokeStyle = "#22D3EE";
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(fx - 20, fy + 35);
            ctx.lineTo(fx + 20, fy + 35);
            
            // Draw arms mapping skeletal movements
            const leftArmY = fy + 55 + Math.cos(frame * 0.08) * 25;
            const rightArmY = fy + 55 + Math.sin(frame * 0.1) * 25;
            ctx.lineTo(fx + 40, rightArmY);
            ctx.moveTo(fx - 20, fy + 35);
            ctx.lineTo(fx - 40, leftArmY);
            ctx.stroke();

            // Joints endpoints
            ctx.fillStyle = "#F43F5E";
            ctx.beginPath();
            ctx.arc(fx - 40, leftArmY, 4, 0, Math.PI * 2);
            ctx.arc(fx + 40, rightArmY, 4, 0, Math.PI * 2);
            ctx.fill();

            requestAnimationFrame(draw);
          };
          draw();
        }
      }
    }
  }, [callState, showAvatarOverlay]);

  const startConversationSimulation = () => {
    const sequence = [
      { gloss: "HELLO_PEER", caption: "Hello! Can you see and hear me clearly?", speaker: "remote" as const, delay: 2000 },
      { gloss: "HEAR_OKAY", caption: "Yes, I can hear you perfectly! The modulated voice output is active.", speaker: "me" as const, delay: 6000 },
      { gloss: "REAL_TIME_STABLE", caption: "Fantastic! Vakhya's translation overlay is rendering at <350ms latency.", speaker: "remote" as const, delay: 11000 },
      { gloss: "INTERPRETER_WANTED", caption: "Should we dispatch a certified sign language interpreter for verification?", speaker: "remote" as const, delay: 17000 }
    ];

    sequence.forEach((step) => {
      setTimeout(() => {
        if (callState !== "connected") return;
        setActiveGloss(step.gloss);
        setActiveCaptions(step.caption);
        setActiveSpeaker(step.speaker);

        // Append to chat stream as well
        setInCallMessages((prev) => [
          ...prev,
          { sender: step.speaker, text: step.caption, time: formatTime(callDuration) }
        ]);

        // Synthesize voice if the profile indicates Deaf person needs to hear voice
        if (step.speaker === "remote" && window.speechSynthesis) {
          const utterance = new SpeechSynthesisUtterance(step.caption);
          utterance.pitch = 1.0;
          utterance.rate = 1.0;
          window.speechSynthesis.speak(utterance);
        }
      }, step.delay);
    });
  };

  const handleSendInCallMessage = () => {
    if (!currentInCallInput.trim()) return;
    setInCallMessages((prev) => [
      ...prev,
      { sender: "me", text: currentInCallInput.trim(), time: formatTime(callDuration) }
    ]);
    setCurrentInCallInput("");
  };

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleTriggerIceRestart = () => {
    setNetworkQuality("reconnecting");
    setTimeout(() => {
      setNetworkQuality("excellent");
      setInCallMessages((prev) => [
        ...prev,
        { sender: "remote", text: "[System]: WebRTC ICE candidates successfully regenerated. Tunnel is stable.", time: formatTime(callDuration) }
      ]);
    }, 2000);
  };

  if (callState === "idle") return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/95 backdrop-blur-3xl z-50 flex items-center justify-center font-sans overflow-hidden">
        
        {/* =============================================================
            1. OUTGOING CALL VIEW
            ============================================================= */}
        {callState === "outgoing" && (
          <div className="text-center space-y-8 flex flex-col items-center justify-center">
            <div className="relative w-36 h-36 flex items-center justify-center">
              <div className="absolute inset-0 bg-[#8A5CF6] rounded-full filter blur-2xl opacity-20 animate-pulse" />
              <div className="absolute inset-0 border border-[#D96FF2]/30 rounded-full scale-125 animate-ping" style={{ animationDuration: "2s" }} />
              <div className="absolute inset-0 border border-purple-500/10 rounded-full scale-150 animate-ping" style={{ animationDuration: "3s" }} />
              <img
                src={callContact?.avatar}
                alt={callContact?.name}
                className="w-24 h-24 rounded-full border-2 border-[#D96FF2] relative z-10"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="space-y-2">
              <h3 className="text-xl font-black text-white">{callContact?.name}</h3>
              <span className="text-xs font-semibold text-purple-300 uppercase tracking-widest font-mono animate-pulse block">
                SECURING SECURE WebRTC SIGNALLING...
              </span>
            </div>

            <button
              onClick={onEndCall}
              className="p-4 rounded-full bg-red-600 text-white hover:bg-red-700 hover:scale-105 active:scale-95 transition-all shadow-[0_0_20px_rgba(220,38,38,0.4)]"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
          </div>
        )}

        {/* =============================================================
            2. INCOMING CALL VIEW (ACCESSIBLE FULL-SCREEN DEAF INTENT)
            ============================================================= */}
        <IncomingCallIntent
          isOpen={callState === "incoming"}
          contact={callContact}
          callType={callType}
          onAccept={onAcceptCall}
          onDecline={onEndCall}
        />

        {/* =============================================================
            3. CONNECTED ACTIVE CALL VIEW
            ============================================================= */}
        {callState === "connected" && (
          <InCallScreen
            remoteUser={callContact || {
              name: "Maya Sharma",
              avatar: "https://api.dicebear.com/7.x/pixel-art/svg?seed=maya",
              phone: "+91 98765 01234",
              userType: "Hearing Profile"
            }}
            callType={callType}
            onEndCall={onEndCall}
            selectedVoicePreset={selectedVoicePreset}
            onUpdateVoicePreset={onUpdateVoicePreset}
          />
        )}

      </div>
    </AnimatePresence>
  );
}
