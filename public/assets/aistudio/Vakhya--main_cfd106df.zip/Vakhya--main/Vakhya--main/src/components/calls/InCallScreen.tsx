/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  Sparkles,
  RefreshCw,
  Volume2,
  Lock,
  Maximize2,
  Minimize2,
  ShieldCheck,
  Languages,
  UserPlus,
  HelpCircle,
  Video as VideoIcon
} from "lucide-react";
import { theme } from "../../theme";

interface InCallScreenProps {
  remoteUser: {
    name: string;
    avatar: string;
    phone: string;
    userType: string;
    statusText?: string;
  };
  callType: "voice" | "video";
  onEndCall: () => void;
  selectedVoicePreset?: string;
  onUpdateVoicePreset?: (preset: string) => void;
}

export default function InCallScreen({
  remoteUser,
  callType,
  onEndCall,
  selectedVoicePreset = "Warm Male",
  onUpdateVoicePreset
}: InCallScreenProps) {
  // Call state toggles
  const [isMuted, setIsMuted] = useState(false);
  const [isCamOn, setIsCamOn] = useState(callType === "video");
  const [isFrontCamera, setIsFrontCamera] = useState(true);
  const [showTranslationOverlay, setShowTranslationOverlay] = useState(true);
  const [callDuration, setCallDuration] = useState(0);

  // Picture-in-Picture sizing & snap positions state
  const [pipSize, setPipSize] = useState<"sm" | "lg">("sm");
  const [pipPosition, setPipPosition] = useState({ x: 0, y: 0 });

  const pipWidth = pipSize === "sm" ? 128 : 176;
  const pipHeight = pipSize === "sm" ? 176 : 240;

  // Translation mock feed
  const [activeGloss, setActiveGloss] = useState("HELLO");
  const [activeSubtitle, setActiveSubtitle] = useState("Hello! Welcome to the secure Vakhya calling gateway.");
  const [isTranslating, setIsTranslating] = useState(true);

  // References
  const containerRef = useRef<HTMLDivElement | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const durationTimerRef = useRef<NodeJS.Timeout | null>(null);
  const skeletonCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  // Call duration counter
  useEffect(() => {
    durationTimerRef.current = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);

    return () => {
      if (durationTimerRef.current) clearInterval(durationTimerRef.current);
    };
  }, []);

  // Format time (MM:SS)
  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Get user camera stream
  useEffect(() => {
    if (isCamOn) {
      navigator.mediaDevices
        ?.getUserMedia({ video: { width: 320, height: 240 }, audio: true })
        .then((stream) => {
          localStreamRef.current = stream;
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
            localVideoRef.current.play().catch(() => {});
          }
        })
        .catch((err) => {
          console.warn("Camera permission not available or rejected:", err);
        });
    } else {
      stopLocalCamera();
    }

    return () => stopLocalCamera();
  }, [isCamOn]);

  const stopLocalCamera = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
    }
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = null;
    }
  };

  // Default / Reset PiP Position to Bottom-Right Corner
  useEffect(() => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setPipPosition({
        x: rect.width - pipWidth - 16,
        y: rect.height - pipHeight - 140 // raised to float nicely above bottom controls
      });
    }
  }, [pipSize]);

  // Handle window resizing to keep the PiP within view boundaries
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setPipPosition((prev) => {
          const isLeft = prev.x < rect.width / 2;
          const isTop = prev.y < rect.height / 2;
          return {
            x: isLeft ? 16 : rect.width - pipWidth - 16,
            y: isTop ? 16 : rect.height - pipHeight - 140
          };
        });
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [pipWidth, pipHeight]);

  // Drag End Snap-to-Corner calculation
  const handleDragEnd = (event: any, info: any) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();

    const corners = {
      "top-left": { x: 16, y: 16 },
      "top-right": { x: rect.width - pipWidth - 16, y: 16 },
      "bottom-left": { x: 16, y: rect.height - pipHeight - 140 },
      "bottom-right": { x: rect.width - pipWidth - 16, y: rect.height - pipHeight - 140 }
    };

    // Calculate release position relative to parent container bounding rect
    const releaseX = info.point.x - rect.left;
    const releaseY = info.point.y - rect.top;

    let closestCorner: keyof typeof corners = "bottom-right";
    let minDistance = Infinity;

    Object.entries(corners).forEach(([key, pt]) => {
      const dx = releaseX - (pt.x + pipWidth / 2);
      const dy = releaseY - (pt.y + pipHeight / 2);
      const dist = dx * dx + dy * dy;
      if (dist < minDistance) {
        minDistance = dist;
        closestCorner = key as any;
      }
    });

    setPipPosition(corners[closestCorner]);
  };

  // Simulated translation overlay pipeline
  useEffect(() => {
    const conversation = [
      { gloss: "HELLO_PEER", subtitle: "Hello! Welcome to the secure Vakhya calling gateway.", delay: 2000 },
      { gloss: "SIGN_FLOW_OK", subtitle: "I am translating your voice speech to sign language coordinates right now.", delay: 6000 },
      { gloss: "LATENCY_FAST", subtitle: "The translation latency is optimized below 320ms for instant dialogue.", delay: 11000 },
      { gloss: "GOODBYE_SYNC", subtitle: "Everything is verified. Looking forward to our call summary!", delay: 17000 }
    ];

    const timers = conversation.map((item) => {
      return setTimeout(() => {
        setActiveGloss(item.gloss);
        setActiveSubtitle(item.subtitle);
      }, item.delay);
    });

    return () => {
      timers.forEach((t) => clearTimeout(t));
    };
  }, []);

  // HTML5 Canvas Skeletal Joint Tracking simulation
  useEffect(() => {
    const canvas = skeletonCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = 180;
    canvas.height = 140;
    let frameId = 0;

    const drawJoints = () => {
      frameId++;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Gradient background for joint tracking box
      ctx.fillStyle = "rgba(24, 34, 41, 0.9)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Subtle cyber grid lines
      ctx.strokeStyle = "rgba(201, 169, 233, 0.08)";
      ctx.lineWidth = 1;
      for (let i = 0; i < canvas.width; i += 20) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, canvas.height);
        ctx.stroke();
      }
      for (let j = 0; j < canvas.height; j += 20) {
        ctx.beginPath();
        ctx.moveTo(0, j);
        ctx.lineTo(canvas.width, j);
        ctx.stroke();
      }

      // Generate simulated hand joints landmarks bouncing gracefully
      const baseLeftX = 50 + Math.sin(frameId * 0.08) * 15;
      const baseLeftY = 80 + Math.cos(frameId * 0.1) * 10;
      
      const baseRightX = 130 + Math.cos(frameId * 0.07) * 15;
      const baseRightY = 80 + Math.sin(frameId * 0.09) * 10;

      // Draw skeleton links (Hands + fingers)
      ctx.lineWidth = 2;
      
      // Left Hand skeletal nodes
      ctx.strokeStyle = "#C9A9E9";
      ctx.beginPath();
      ctx.moveTo(baseLeftX, baseLeftY);
      ctx.lineTo(baseLeftX - 10, baseLeftY - 20);
      ctx.moveTo(baseLeftX, baseLeftY);
      ctx.lineTo(baseLeftX, baseLeftY - 25);
      ctx.moveTo(baseLeftX, baseLeftY);
      ctx.lineTo(baseLeftX + 10, baseLeftY - 18);
      ctx.stroke();

      // Right Hand skeletal nodes
      ctx.strokeStyle = "#22D3EE";
      ctx.beginPath();
      ctx.moveTo(baseRightX, baseRightY);
      ctx.lineTo(baseRightX - 10, baseRightY - 18);
      ctx.moveTo(baseRightX, baseRightY);
      ctx.lineTo(baseRightX, baseRightY - 25);
      ctx.moveTo(baseRightX, baseRightY);
      ctx.lineTo(baseRightX + 10, baseRightY - 20);
      ctx.stroke();

      // Draw Joint coordinate dots
      ctx.fillStyle = "#F43F5E";
      const joints = [
        [baseLeftX, baseLeftY],
        [baseLeftX - 10, baseLeftY - 20],
        [baseLeftX, baseLeftY - 25],
        [baseLeftX + 10, baseLeftY - 18],
        [baseRightX, baseRightY],
        [baseRightX - 10, baseRightY - 18],
        [baseRightX, baseRightY - 25],
        [baseRightX + 10, baseRightY - 20]
      ];

      joints.forEach(([x, y]) => {
        ctx.beginPath();
        ctx.arc(x, y, 3.5, 0, Math.PI * 2);
        ctx.fill();

        // Small pulse ring
        ctx.strokeStyle = "rgba(244, 63, 94, 0.4)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(x, y, 6 + Math.sin(frameId * 0.2) * 2, 0, Math.PI * 2);
        ctx.stroke();
      });

      // Joint connection metrics info text
      ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
      ctx.font = "8px monospace";
      ctx.fillText("ASL Skeletal Rigg", 6, 12);
      ctx.fillStyle = "#22D3EE";
      ctx.fillText("FPS: 60.2", 130, 12);

      requestAnimationFrame(drawJoints);
    };

    drawJoints();
  }, []);

  return (
    <div
      ref={containerRef}
      id="incall-screen-wrapper"
      className="absolute inset-0 bg-[#111b21] z-50 overflow-hidden flex flex-col justify-between font-sans select-none"
    >
      {/* 1. TOP HEADER OVERLAY (Sleek frosted WhatsApp bar) */}
      <div className="absolute top-0 inset-x-0 bg-gradient-to-b from-black/85 via-black/45 to-transparent p-5 pt-8 z-30 flex justify-between items-start">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={remoteUser.avatar}
              alt={remoteUser.name}
              className="w-11 h-11 rounded-full border-2 border-[#C9A9E9] bg-[#182229] p-0.5 object-cover"
              referrerPolicy="no-referrer"
            />
            <span className="absolute -bottom-1 -right-1 p-0.5 bg-emerald-500 rounded-full border border-[#111b21]">
              <ShieldCheck className="w-2.5 h-2.5 text-white" />
            </span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-bold text-sm text-white tracking-wide">{remoteUser.name}</h3>
              <span className="text-[8px] font-mono font-bold bg-[#C9A9E9]/20 border border-[#C9A9E9]/30 px-1.5 py-0.2 rounded-full text-[#C9A9E9] uppercase">
                {remoteUser.userType.split(" ")[0]}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono text-white/50 mt-0.5">
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                SECURE WebRTC
              </span>
              <span>•</span>
              <span className="text-[#C9A9E9] font-semibold">{formatTime(callDuration)}</span>
            </div>
          </div>
        </div>

        {/* Right tools (Group size, lock status) */}
        <div className="flex gap-2">
          <div className="flex items-center gap-1.5 py-1.5 px-3 rounded-full bg-black/40 backdrop-blur-md border border-white/5 text-[10px] font-mono text-white/80">
            <Lock className="w-3.5 h-3.5 text-[#C9A9E9]" />
            <span>AES-256</span>
          </div>
          <button
            onClick={() => {}}
            className="p-2 rounded-full bg-black/40 border border-white/5 hover:bg-black/60 text-white/70"
            title="Invite certified Interpreter"
          >
            <UserPlus className="w-4 h-4 text-[#C9A9E9]" />
          </button>
        </div>
      </div>

      {/* 2. MAIN MIDDLE VIDEO COMPONENT */}
      <div className="flex-1 relative flex items-center justify-center">
        
        {/* Full Remote video container with mock fallback or gorgeous animated blobs */}
        <div className="absolute inset-0 w-full h-full bg-[#111b21] overflow-hidden flex items-center justify-center">
          
          {/* Lavender Aurora Animated Background Blobs */}
          <div className="absolute inset-0 z-0 opacity-40">
            <motion.div
              animate={{
                x: [0, 40, -20, 0],
                y: [0, -30, 40, 0],
                scale: [1, 1.15, 0.9, 1]
              }}
              transition={{
                duration: 15,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute -top-20 -left-20 w-[400px] h-[400px] rounded-full bg-gradient-to-tr from-[#C9A9E9] to-[#7B5EA7] blur-[90px]"
            />
            <motion.div
              animate={{
                x: [0, -50, 30, 0],
                y: [0, 40, -30, 0],
                scale: [1, 0.9, 1.2, 1]
              }}
              transition={{
                duration: 18,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute -bottom-32 -right-32 w-[500px] h-[500px] rounded-full bg-gradient-to-bl from-[#EFE3FB] to-[#C9A9E9] blur-[100px]"
            />
            <motion.div
              animate={{
                x: [0, 30, -30, 0],
                y: [0, 20, 20, 0],
                scale: [1, 1.1, 1, 1]
              }}
              transition={{
                duration: 12,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute top-1/4 left-1/4 w-[350px] h-[350px] rounded-full bg-gradient-to-br from-[#C9A9E9] to-[#3E2C64] blur-[90px]"
            />
          </div>

          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(201,169,233,0.08)_0%,transparent_85%)] pointer-events-none z-0" />

          {/* Remote user avatar display placeholder */}
          <div className="text-center space-y-4 relative z-10 p-6">
            <div className="relative inline-block">
              {/* Pulsing ring */}
              <div className="absolute w-36 h-36 bg-[#C9A9E9]/10 rounded-full border border-[#C9A9E9]/20 animate-ping" style={{ animationDuration: "2.5s" }} />
              <div className="absolute w-48 h-48 bg-[#C9A9E9]/5 rounded-full border border-[#C9A9E9]/10 animate-ping" style={{ animationDuration: "4s" }} />
              
              <img
                src={remoteUser.avatar}
                alt={remoteUser.name}
                className="w-32 h-32 rounded-full border-4 border-[#1f2c34] bg-[#182229] relative z-10 object-cover shadow-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-[#C9A9E9] uppercase block font-bold">
                Remote Video Signal
              </span>
              <h2 className="text-xl font-black text-white tracking-wide mt-1">
                {remoteUser.name}
              </h2>
              <p className="text-xs text-white/40 mt-1 max-w-xs mx-auto">
                {remoteUser.statusText || "Voice synthesizer & skeletal landmark engines active..."}
              </p>
            </div>
          </div>
        </div>

        {/* =============================================================
            A. DRAGGABLE & RESIZABLE SELF-PREVIEW WINDOW (WhatsApp-Grade Snaps)
            ============================================================= */}
        <motion.div
          drag
          dragConstraints={containerRef}
          dragElastic={0.05}
          dragMomentum={false}
          onDragEnd={handleDragEnd}
          animate={pipPosition}
          transition={{ type: "spring", stiffness: 350, damping: 28 }}
          id="draggable-self-video"
          className="absolute bg-[#182229] border-2 border-[#C9A9E9]/40 rounded-2xl overflow-hidden shadow-[0_12px_40px_rgba(0,0,0,0.6)] z-40 cursor-grab active:cursor-grabbing"
          style={{ top: 0, left: 0, width: pipWidth, height: pipHeight }}
        >
          {isCamOn ? (
            <video
              ref={localVideoRef}
              className={`w-full h-full object-cover rounded-2xl ${isFrontCamera ? "scale-x-[-1]" : ""}`}
              muted
              playsInline
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center bg-[#111b21] space-y-2">
              <div className="w-10 h-10 rounded-full bg-[#C9A9E9]/20 flex items-center justify-center text-white/60">
                <VideoOff className="w-5 h-5 text-[#C9A9E9]" />
              </div>
              <span className="text-[9px] font-mono text-[#C9A9E9]">Cam Off</span>
            </div>
          )}

          {/* Miniature Overlay Tag */}
          <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-md text-[8px] font-mono text-white/90">
            YOU
          </div>

          {/* Resize Toggle inside PiP */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setPipSize((prev) => (prev === "sm" ? "lg" : "sm"));
            }}
            className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-[#C9A9E9]/40 rounded-md text-white transition-colors z-50 cursor-pointer"
            title={pipSize === "sm" ? "Enlarge PiP Preview" : "Minimize PiP Preview"}
          >
            {pipSize === "sm" ? <Maximize2 className="w-3.5 h-3.5 text-[#C9A9E9]" /> : <Minimize2 className="w-3.5 h-3.5 text-[#C9A9E9]" />}
          </button>
        </motion.div>

        {/* =============================================================
            B. LIVE TRANSLATION OVERLAY & SKELETAL COORD PIP
            ============================================================= */}
        <AnimatePresence>
          {showTranslationOverlay && (
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-end p-6 pb-28">
              
              {/* 3D Skeletal Landmark tracking visualizer (Floating in space) */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="absolute left-6 top-28 bg-[#182229]/90 backdrop-blur-md border border-[#C9A9E9]/30 rounded-2xl p-1 shadow-2xl pointer-events-auto overflow-hidden"
              >
                <div className="text-[8px] font-mono text-[#C9A9E9] px-2 py-1 bg-black/20 font-bold tracking-wider flex items-center gap-1 border-b border-white/5">
                  <Sparkles className="w-3 h-3 text-[#C9A9E9] animate-pulse" />
                  AI HAND COORDINATES
                </div>
                <canvas ref={skeletonCanvasRef} className="rounded-b-xl block" />
              </motion.div>

              {/* Subtitles Overlay Banner (Frosted, styled with generous spacing) */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                className="mx-auto w-full max-w-xl bg-black/65 backdrop-blur-xl border border-white/10 rounded-2xl p-4 text-center shadow-2xl pointer-events-auto space-y-1.5"
              >
                <div className="flex justify-between items-center text-[8px] font-mono tracking-widest text-[#C9A9E9] font-bold uppercase border-b border-white/5 pb-1">
                  <span className="flex items-center gap-1">
                    <Languages className="w-3.5 h-3.5" />
                    Continuous AI Translate
                  </span>
                  <span className="text-[#C9A9E9]">Active Gloss: {activeGloss}</span>
                </div>
                
                <p className="text-xs text-white leading-relaxed font-semibold">
                  "{activeSubtitle}"
                </p>

                <div className="flex justify-center items-center gap-4 text-[9px] text-white/40 pt-1">
                  <span>Engine: Vakhya Core 4.0</span>
                  <span>•</span>
                  <span className="text-[#22D3EE] font-semibold">Latency: 310ms</span>
                </div>
              </motion.div>
              
            </div>
          )}
        </AnimatePresence>
      </div>

      {/* 3. BOTTOM CONTROL DOCK (WhatsApp pill floating layout) */}
      <div className="bg-gradient-to-t from-black via-black/90 to-transparent pt-10 pb-8 px-6 z-30">
        
        {/* Call options mini info rail */}
        <div className="flex justify-between items-center max-w-sm mx-auto mb-4 text-[10px] font-mono text-white/50 bg-[#182229]/60 p-2 rounded-xl border border-white/5">
          <span className="flex items-center gap-1">
            <Volume2 className="w-3.5 h-3.5 text-[#C9A9E9]" />
            Vocal DSP: {selectedVoicePreset}
          </span>
          <span className="text-emerald-400 font-bold">Bitrate: 1411 kbps</span>
        </div>

        {/* WhatsApp-grade Controls Circle Pill */}
        <div className="flex justify-between items-center max-w-md mx-auto bg-[#182229]/90 backdrop-blur-3xl border border-white/10 rounded-full px-6 py-4 shadow-2xl">
          
          {/* Mute Mic button */}
          <button
            id="incall-mute-btn"
            onClick={() => setIsMuted(!isMuted)}
            className={`w-12 h-12 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
              isMuted
                ? "bg-red-500/20 border-red-500 text-red-300 shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                : "bg-white/5 border-white/10 text-white hover:bg-white/10"
            }`}
            title="Mute Audio"
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Toggle Local Camera button */}
          <button
            id="incall-camera-btn"
            onClick={() => setIsCamOn(!isCamOn)}
            className={`w-12 h-12 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
              !isCamOn
                ? "bg-red-500/20 border-red-500 text-red-300"
                : "bg-white/5 border-white/10 text-white hover:bg-white/10"
            }`}
            title="Toggle Camera"
          >
            {isCamOn ? <VideoIcon className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
          </button>

          {/* Camera Flip / Orientation button */}
          <button
            id="incall-flip-btn"
            onClick={() => setIsFrontCamera(!isFrontCamera)}
            className={`w-12 h-12 rounded-full bg-white/5 border border-white/10 text-white hover:bg-white/10 flex items-center justify-center transition-all cursor-pointer`}
            title="Flip Camera orientation"
          >
            <RefreshCw className="w-5 h-5 animate-pulse text-[#C9A9E9]" />
          </button>

          {/* Translation overlay panel toggle */}
          <button
            id="incall-overlay-btn"
            onClick={() => setShowTranslationOverlay(!showTranslationOverlay)}
            className={`w-12 h-12 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
              showTranslationOverlay
                ? "bg-[#C9A9E9]/25 border-[#C9A9E9] text-[#C9A9E9]"
                : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10"
            }`}
            title="Toggle Translation Overlays"
          >
            <Languages className="w-5 h-5" />
          </button>

          {/* End Call (Red Circular button) */}
          <button
            id="incall-end-btn"
            onClick={onEndCall}
            className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-700 hover:shadow-[0_0_20px_rgba(220,38,38,0.5)] text-white flex items-center justify-center transition-transform active:scale-95 shadow-lg cursor-pointer animate-pulse"
            title="End Session"
          >
            <PhoneOff className="w-6 h-6 rotate-[135deg]" />
          </button>

        </div>
      </div>
    </div>
  );
}
